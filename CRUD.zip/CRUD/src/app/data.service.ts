import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../environments/environment';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';


@Injectable({
  providedIn: 'root'
})
export class DataService {

  constructor(private http: HttpClient) { }

  getTask():Observable<any>{
    return this.http.get(`https://tasksmanager-302f5.firebaseio.com/Task.json`)
    .pipe(
      map(result=>result)
    );
  }
}
